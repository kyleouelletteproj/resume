
<?php
	$verb_escaped = $_GET['verb1'];
	$verb2_escaped = $_GET['verb2'];
	$verb3_escaped = $_GET['verb3'];
	$noun1_escaped = $_GET['noun1'];
	$noun2_escaped = $_GET['noun2'];
	$noun3_escaped = $_GET['noun3'];
	$adjective1_escaped = $_GET['adjective1'];
	$adjective2_escaped = $_GET['adjective2'];
	$adjective3_escaped = $_GET['adjective3'];
	

	$madlib3 = "Their once was a man who wanted to own a " . $noun1_escaped " machine. Lets call him Ted. Unfortunetly he had no idea how to even run a functioning " . $noun1_escaped " machine. So like any other " . $adjective1_escaped " person Ted decided to go on the internet to find out. Ted found out that the averge machine cost could vary from a " . $adjective2_escaped " low amount to a very massive amount of money. For just $200 Ted could " . $verb1_escaped " a machine for a steal of a price. However, even after buying one, it is also important to purchase the needed ". $noun2_escaped " incase the machine breaks and needs to be fixed. While a cheaper model may be easier to obtain, they will also require a lot more repairs or possible quick fixes. In addition to just owning one, its alos important to put a lot of " . $noun3_escaped " for people to purchase while they " . $verb2_escaped " around whatever shopping center the machine may end up in. Speaking of shopping centers it will be important to make an agreement with whoever may own the property the machine will be on. Typically it is not unheard of to get a " . $adjective3_escaped " lawyer to quickly put together a contract in order for both parties to " . $verb3_escaped ". And that's generally what goes into owning a " . $noun1_escaped " machine, atleast that what the article on vending machines says..";
?>
